<#	
    .NOTES
    ===========================================================================
        Created on:   	04.10.2015
        Created by:   	David das Neves
        Version:        0.1
        Project:        GUI_Manager
        Filename:       GUI_Manager.psm1
    ===========================================================================
    .DESCRIPTION
        Functions for GUI_Manager.
#> 

#===========================================================================
#region loading external functions



#endregion

#region functions



#endregion
#===========================================================================
